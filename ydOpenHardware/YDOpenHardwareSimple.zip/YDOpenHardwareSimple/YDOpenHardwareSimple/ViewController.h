//
//  ViewController.h
//  YDOpenHardwareSimple
//
//  Created by 张旻可 on 16/2/2.
//  Copyright © 2016年 YD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

