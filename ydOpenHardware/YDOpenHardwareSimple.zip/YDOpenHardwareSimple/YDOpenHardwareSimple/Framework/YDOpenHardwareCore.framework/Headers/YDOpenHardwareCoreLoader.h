//
//  YDOpenHardwareCoreLoader.h
//  YDOpenHardwareCore
//
//  Created by 张旻可 on 16/2/14.
//  Copyright © 2016年 YD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YDOpenHardwareCoreLoader : NSObject

+ (void)load;

@end
