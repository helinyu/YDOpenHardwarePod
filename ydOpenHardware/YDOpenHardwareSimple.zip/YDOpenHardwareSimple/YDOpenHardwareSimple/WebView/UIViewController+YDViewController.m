//
//  UIViewController+YDViewController.m
//  SportsBar
//
//  Created by 张旻可 on 2017/4/14.
//  Copyright © 2017年 apple. All rights reserved.
//

#import "UIViewController+YDViewController.h"

@implementation UIViewController (YDViewController)

@end
