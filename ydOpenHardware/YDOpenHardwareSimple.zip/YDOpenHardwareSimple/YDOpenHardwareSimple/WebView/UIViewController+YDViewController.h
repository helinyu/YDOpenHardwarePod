//
//  UIViewController+YDViewController.h
//  SportsBar
//
//  Created by 张旻可 on 2017/4/14.
//  Copyright © 2017年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (YDViewController)

@property (nonatomic, readonly, assign) BOOL isViewAppear;
@property (nonatomic, readonly, copy) NSString *uuid;

@end
