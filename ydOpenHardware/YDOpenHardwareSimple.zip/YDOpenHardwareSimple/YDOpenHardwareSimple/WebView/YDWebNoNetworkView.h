//
//  YDWebNoNetworkView.h
//  SportsBar
//
//  Created by 张旻可 on 2017/4/11.
//  Copyright © 2017年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YDWebNoNetworkView : UIView

@property (nonatomic, copy) void(^actionRefresh)();

@end
