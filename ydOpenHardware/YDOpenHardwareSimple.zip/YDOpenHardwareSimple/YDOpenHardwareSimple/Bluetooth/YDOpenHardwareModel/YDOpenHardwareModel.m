//
//  YDOpenHardwareModel.m
//  YDOpenHardwareSimple
//
//  Created by Aka on 2017/8/4.
//  Copyright © 2017年 YD. All rights reserved.
//

#import "YDOpenHardwareModel.h"

@implementation YDOpenHardwareModel

@end

@implementation YDOpenHardwareSleep (YDOpenHardwareModel)

@end


