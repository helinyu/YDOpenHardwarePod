//
//  YDOpenHardwareModel.h
//  YDOpenHardwareSimple
//
//  Created by Aka on 2017/8/4.
//  Copyright © 2017年 YD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <YDOpenHardwareSDK/YDOpenHardwareSleep.h>

@interface YDOpenHardwareModel : NSObject

@end

@interface YDOpenHardwareModel (YDOpenHardwareSleep)


@end

