//
//  NSString+YDContainsString.h
//  SportsBar
//
//  Created by 张旻可 on 2016/12/26.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (YDContainsString)

- (BOOL)containsString:(NSString *)str;

@end
